# Jyang博客后端部署包

## 部署步骤

### 方法一：直接启动

1. 确保已安装Node.js (推荐v14.x或更高版本)
2. 在Windows上双击 `start.bat` 或在Linux/Mac上运行 `./start.sh`

### 方法二：使用PM2（推荐用于生产环境）

1. 全局安装PM2: `npm install -g pm2`
2. 使用PM2启动应用: `pm2 start ecosystem.config.js`
3. 设置开机自启: `pm2 startup` 然后按照提示操作
4. 保存PM2配置: `pm2 save`

## 环境变量配置

应用的配置存储在 `.env` 文件中，可以根据需要修改：

- PORT: 应用监听端口
- MONGO_URI: MongoDB连接字符串
- JWT_SECRET: JWT密钥（如果使用JWT认证）

## 常用PM2命令

- 查看应用状态: `pm2 list`
- 查看日志: `pm2 logs jyang-blog-server`
- 重启应用: `pm2 restart jyang-blog-server`
- 停止应用: `pm2 stop jyang-blog-server`

## Nginx配置示例

如果使用Nginx作为反向代理，可以参考以下配置：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 注意事项

- 确保MongoDB服务器已启动并可访问
- 确保服务器防火墙已开放应用端口
- 生产环境建议使用Nginx等反向代理
